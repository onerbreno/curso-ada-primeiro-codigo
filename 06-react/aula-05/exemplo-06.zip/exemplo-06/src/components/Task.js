import { useState } from "react";
import { Link } from "react-router-dom";

function Task(props){

    const [checked, setChecked] = useState(true);

    return(

        <div className={`task ${ checked && 'completed'}`}>
            <input type="checkbox" checked={checked} onChange={() => setChecked(!checked)} id="task1"/>
            <Link to={`tasks/${props.id}`}>{props.title}</Link>
        </div>
    )
}

export default Task;