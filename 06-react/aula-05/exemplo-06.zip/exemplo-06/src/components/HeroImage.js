const HeroImage = () => {
    return(
        <img height="120" src="https://i.imgur.com/7KxXhNI.jpeg" alt="Ada" className="photo"/>
    )
}

export default HeroImage;