
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import ListTaskPage from './pages/ListTaskPage';
import TaskDetailPage from './pages/TaskDetailPage';
import Header from './components/Header';
import HeroImage from './components/HeroImage';

function App() {
  return (
    <div className="App">
        <Header/>
        <HeroImage/>
      <BrowserRouter>
        <Routes>
            <Route path='/' element={<ListTaskPage/>}/>
            <Route path='/tasks/:taskId' element={<TaskDetailPage/>}/>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
