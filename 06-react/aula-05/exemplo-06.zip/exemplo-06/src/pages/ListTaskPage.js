import TaskList from '../components/TaskList';

function ListTaskPage(){

    return(
        <TaskList/>
    )
}

export default ListTaskPage;