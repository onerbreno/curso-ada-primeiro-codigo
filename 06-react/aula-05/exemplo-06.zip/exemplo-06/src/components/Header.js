const Header = () => {
    return(
        <h1>Ada Lovelace's Todos</h1>
    )
}

export default Header;